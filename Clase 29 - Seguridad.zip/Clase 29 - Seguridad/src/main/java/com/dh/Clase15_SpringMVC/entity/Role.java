package com.dh.Clase15_SpringMVC.entity;

public enum Role {
    USER,
    ADMIN
}
