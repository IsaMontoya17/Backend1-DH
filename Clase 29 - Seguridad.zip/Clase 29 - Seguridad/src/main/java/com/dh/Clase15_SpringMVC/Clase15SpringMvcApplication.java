package com.dh.Clase15_SpringMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase15SpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase15SpringMvcApplication.class, args);
	}

}
