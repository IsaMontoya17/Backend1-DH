package com.digitalhouse.odontologia.services;

import com.digitalhouse.odontologia.dao.IDAO;
import com.digitalhouse.odontologia.dao.impl.OdontologoDaoH2;
import com.digitalhouse.odontologia.domain.Odontologo;

import java.util.List;

public class OdontologoService {

    private IDAO<Odontologo> interfazDao;

    public OdontologoService() {
        interfazDao = new OdontologoDaoH2();
    }

    public Odontologo guardar(Odontologo odontologo){
        return interfazDao.guardar(odontologo);
    }

    public List<Odontologo> listar(){
        return interfazDao.listar();
    }
}