package com.digitalhouse.odontologia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OdontologiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdontologiaApplication.class, args);
	}

}
